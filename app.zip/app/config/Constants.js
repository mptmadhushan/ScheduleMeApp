export const IOS_KEY_CHAIN_NAME = 'keyChainScheduleMe';
export const ANDROID_SHARED_PREF_NAME = 'sharedPreferencesScheduleMe';

export const COLOR_BLUE = '#2b6fb3';
export const COLOR_WHITE = '#ffffff';
export const COLOR_GREEN = '#5aa469';
export const COLOR_RED = '#d35d6e';

// export const IP_ADDRESS = '192.168.8.102:5000';
export const IP_ADDRESS = '192.168.8.100:5000';
