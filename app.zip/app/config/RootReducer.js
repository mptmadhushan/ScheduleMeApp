import AuthReducer from '../data/reducers/AuthReducer';

const RootReducer = {
    auth: AuthReducer,
};

export default RootReducer;