import React, {useEffect} from 'react';
import {Provider} from 'react-redux';
import {PersistGate} from 'redux-persist/integration/react';
import {Root} from 'native-base';
import SplashScreen from 'react-native-splash-screen';
import ReactNativeAN from 'react-native-alarm-notification';
const fireDate = '01-01-2060 00:00:00';
import AppStore from './config/AppStore';
import MainNavigation from '../app/config/navigation/MainNavigation';

const {store, persistor} = AppStore();
const alarmNotifData = {
  title: 'My Notification Title',
  message: 'My Notification Message',
  channel: 'my_channel_id',
  small_icon: 'ic_launcher',
  data: {foo: 'bar'},
};
const App = () => {
  useEffect(() => {
    SplashScreen.hide();
  });

  return (
    <Provider store={store}>
      <PersistGate persistor={persistor}>
        <Root>
          <MainNavigation />
        </Root>
      </PersistGate>
    </Provider>
  );
};

export default App;
